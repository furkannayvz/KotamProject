import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserStorage {
  static const String userKey = 'registered_user';

  static Future<void> saveUser(Map<String, dynamic> userData) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(userKey, jsonEncode(userData));
  }

static Future<void> clearUser() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.remove(userKey);
}

  static Future<Map<String, dynamic>?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString(userKey);
    if (userString != null) {
      return jsonDecode(userString);
    }
    return null;
  }
static String normalizePhone(String input) {
  final digits = input.replaceAll(RegExp(r'\D'), '');

  // +90 veya 0 ile başlıyorsa baştan at
  if (digits.startsWith('90')) {
    return digits.substring(2);
  } else if (digits.startsWith('0')) {
    return digits.substring(1);
  } else {
    return digits;
  }
}

static Future<bool> validateLogin(String phone, String password) async {
  final user = await getUser();
  if (user == null) return false;

  final inputPhone = normalizePhone(phone);
  final storedPhone = normalizePhone(user['phone']);

  debugPrint('📲 Giriş Telefonu: $inputPhone');
  debugPrint('📲 Kayıtlı Telefon: $storedPhone');
  debugPrint('🔐 Giriş Şifresi: $password');
  debugPrint('🔐 Kayıtlı Şifre: ${user['password']}');

  return storedPhone == inputPhone && user['password'] == password;
}

}
