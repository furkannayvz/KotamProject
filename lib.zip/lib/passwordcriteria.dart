import 'package:flutter/material.dart';

class PasswordCriteriaRow extends StatelessWidget {
  final String text;
  final bool isValid;

  const PasswordCriteriaRow({super.key, 
    required this.text,
    required this.isValid,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          isValid ? Icons.check_circle : Icons.radio_button_unchecked,
          color: isValid ? Colors.green : Colors.grey,
        ),
        SizedBox(width: 10),
        Text(text),
      ],
    );
  }
}
