// ignore_for_file: library_private_types_in_public_api

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class CodeInputPage extends StatefulWidget {
  const CodeInputPage({super.key});

  @override
  _CodeInputPageState createState() => _CodeInputPageState();
}

class _CodeInputPageState extends State<CodeInputPage> {
  final TextEditingController _codeController = TextEditingController();
  String currentCode = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            SizedBox(height: 150),

            Row(children: [Image.asset("images/image 10.png")]),
            Text(
              "Please enter the 5-digitpassword we sent to your email account",
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 24),
            PinCodeTextField(
              appContext: context,
              length: 5,
              controller: _codeController,
              onCompleted: (value) {
                if (value != currentCode) {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(SnackBar(content: Text("Şifre yanlış")));
                } else {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(SnackBar(content: Text("Şifre Doğru")));
                }
              },
              autoDisposeControllers: false,
              pinTheme: PinTheme(
                shape: PinCodeFieldShape.box,
                borderRadius: BorderRadius.circular(8),
                fieldHeight: 60,
                fieldWidth: 60,
                activeFillColor: Colors.white,
                selectedColor: Colors.blue,
                activeColor: Colors.blue,
                inactiveColor: Colors.grey,
              ),
              keyboardType: TextInputType.number,
              animationType: AnimationType.fade,
              enableActiveFill: false,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    resendCode(context);
                  },
                  child: Text(
                    "Resend Code",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            GestureDetector(
              onTap: () => Navigator.pushNamed(context, '/NewPassword'),
              child: Container(
                height: 60,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 33, 39, 44),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text("Confirm", style: TextStyle(color: Colors.white)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  resendCode(BuildContext context) {
    // 5 haneli rastgele sayı üret
    final random = Random();
    currentCode = List.generate(5, (_) => random.nextInt(10)).join();

    // SnackBar ile göster
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("New code: $currentCode"),
        duration: Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
      ),
    );

    // İstersen burada SharedPreferences veya API gönderimi de ekleyebilirsin
  }
}
