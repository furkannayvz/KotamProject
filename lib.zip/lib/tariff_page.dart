// ignore_for_file: library_private_types_in_public_api, avoid_print, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'user_storage.dart';

class TariffPage extends StatefulWidget {
  const TariffPage({super.key});

  @override
  _TariffPageState createState() => _TariffPageState();
}

class _TariffPageState extends State<TariffPage> {
  List<dynamic> tariffs = [];
  dynamic selectedTariff;

  @override
  void initState() {
    super.initState();
    fetchTariffs();
  }

  Future<void> fetchTariffs() async {
    final url = Uri.parse('http://34.14.39.115/api/packages/all');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          tariffs = json.decode(response.body);
        });
      }
    } catch (e) {
      print('Hata: $e');
    }
  }

  void selectTariffAndContinue(BuildContext context) async {
    if (selectedTariff == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Please select a tariff')));
      return;
    }

    final userData = await UserStorage.getUser();
    if (userData == null) return;

    userData['selectedTariff'] = selectedTariff;

    await UserStorage.saveUser(userData);

    Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: tariffs.isEmpty
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [
                SizedBox(height: 50),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Image.asset("images/image 10.png", width: 120),

                    IconButton(
                      icon: Icon(Icons.logout),
                      onPressed: () async {
                        await UserStorage.clearUser();
                        Navigator.pushNamedAndRemoveUntil(
                          context,
                          '/',
                          (_) => false,
                        );
                      },
                    ),
                  ],
                ),
                Row(
                  children: [
                    Text(
                      "My Tariff",
                      style: TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      "Choose the perfect plan for your needs",
                      style: TextStyle(color: Colors.grey[700], fontSize: 18),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Expanded(
                  child: ListView.builder(
                    itemCount: tariffs.length,
                    itemBuilder: (context, index) {
                      final tariff = tariffs[index];
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: GestureDetector(
                          onTap: () => setState(() => selectedTariff = tariff),
                          child: Container(
                            margin: EdgeInsets.only(bottom: 16),
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              gradient: LinearGradient(
                                colors: selectedTariff == tariff
                                    ? [Color(0xFF264973), Color(0xFF3B74B0)]
                                    : [Color(0xFF1F2F5F), Color(0xFF2B468B)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 8,
                                  offset: Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  tariff['name'],
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(height: 8),
                                Text(
                                  '${tariff['price']}₺/month',
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(height: 12),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    _tariffDetailDot(
                                      "📶 ${tariff['dataQuota']} data",
                                    ),
                                    _tariffDetailDot(
                                      "📞 ${tariff['minutesQuota']} minutes",
                                    ),
                                    _tariffDetailDot(
                                      "✉️ ${tariff['smsQuota']} sms",
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 4.0,
                    horizontal: 8,
                  ),

                  child: GestureDetector(
                    onTap: () => selectTariffAndContinue(context),

                    child: Container(
                      height: 60,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 4, 18, 29),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: Text(
                          "Sign Up",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 4.0,
                    horizontal: 8,
                  ),
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      height: 60,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 33, 39, 44),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: Text(
                          "Back",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _tariffDetailDot(String text) {
    return Row(
      children: [
        Icon(Icons.circle, size: 8, color: Colors.white70),
        SizedBox(width: 6),
        Text(text, style: TextStyle(color: Colors.white)),
      ],
    );
  }
}
