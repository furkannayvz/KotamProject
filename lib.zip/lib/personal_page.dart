// ignore_for_file: library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'user_storage.dart';

class PersonalPage extends StatefulWidget {
  const PersonalPage({super.key});

  @override
  _PersonalPageState createState() => _PersonalPageState();
}

class _PersonalPageState extends State<PersonalPage> {
  Map<String, dynamic>? userData;

  @override
  void initState() {
    super.initState();
    loadUser();
  }

  Future<void> loadUser() async {
    final data = await UserStorage.getUser();
    setState(() {
      userData = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (userData == null) {
      return Scaffold(
        appBar: AppBar(title: Text('Personal Information')),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final tariff = userData!['selectedTariff'];
    final fullName = "${userData!['name']} ${userData!['surname']}";

    double percentUsed = 1; // Sabit demo oranı

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, "/");
            },
            icon: Icon(Icons.no_accounts),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Welcome\n$fullName",
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),

              SizedBox(height: 24),
              Text(
                "Remaining Usage",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),

              SizedBox(height: 16),
              usageIndicator(
                "Data",
                percentUsed,
                "${tariff['dataQuota'] / 1000} GB",
              ),
              usageIndicator(
                "Minutes",
                percentUsed,
                "${tariff['minutesQuota']} dk",
              ),
              usageIndicator("SMS", percentUsed, "${tariff['smsQuota']} SMS"),

              SizedBox(height: 24),
              Text(
                "My Plan",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),

              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    // Üst Mavi Başlık Alanı
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 13, 29, 53),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: EdgeInsets.all(16),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "${tariff['packageName']}",

                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              "Expires on November 12",
                              style: TextStyle(color: Colors.white70),
                            ),
                            Text(
                              "(24 days left)",
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 16),

                    // Kalan gün ve tarih barı
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "  24 days left",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(height: 4),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: 0.8, // örnek oran
                          minHeight: 8,
                          backgroundColor: Colors.grey[300],
                          color: Colors.blue.shade800,
                        ),
                      ),
                    ),
                    SizedBox(height: 4),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        "12/07/2025  ",
                        style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                      ),
                    ),

                    SizedBox(height: 16),

                    // Alt kısım: SMS, Data, Minutes
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        infoTile("SMS", tariff['smsQuota'].toString()),
                        infoTile("Data", "${tariff['dataQuota'] / 1000} MB"),
                        infoTile("Minute", tariff['minutesQuota'].toString()),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget usageIndicator(String label, double percent, String quotaText) {
    final tariff = userData!['selectedTariff']["name"];
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.white,
        ),

        child: Row(
          children: [
            CircularPercentIndicator(
              startAngle: 180,
              radius: 50.0,
              lineWidth: 10.0,
              percent: percent,
              center: Text("${(percent * 100).toStringAsFixed(1)}%"),
              progressColor: Colors.indigo[900],
              backgroundColor: Color(0xFFE0E0E0),
              circularStrokeCap: CircularStrokeCap.round,
            ),
            SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "$tariff "
                  "$label",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                Text(quotaText),
                Text("Expires on November 12"),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget infoTile(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        Text(label),
      ],
    );
  }
}
