import 'package:flutter/material.dart';
import 'package:loginn/forgotpassword.dart';
import 'package:loginn/newpassword.dart';
import 'package:loginn/pinput.dart';
import 'login_page.dart';
import 'register_page.dart';
import 'tariff_page.dart';
import 'personal_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey,
      title: 'Flutter Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),
        '/tariff': (context) => TariffPage(),
        '/personal': (context) => PersonalPage(),
        '/NewPassword': (context) => NewPassword(),
        '/Forgot': (context) => ForgotPassword(),
        '/pinput': (context) => CodeInputPage(),
      },
    );
  }
}
