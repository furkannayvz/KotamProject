import 'package:flutter/material.dart';

class NewPassword extends StatefulWidget {
  const NewPassword({super.key});

  @override
  State<NewPassword> createState() => _NewPasswordState();
}

class _NewPasswordState extends State<NewPassword> {
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController newConfirmPasswordController = TextEditingController();

  @override
  void dispose() {
    newPasswordController.dispose();
    newConfirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              SizedBox(height: 140),
              Row(children: [Image.asset("images/image 10.png")]),
              Row(
                children: [
                  Text(
                    "New Password",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 48),
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    "New Password",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
              SizedBox(height: 10),
              TextField(
                controller: newPasswordController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),

                  hintText: 'Your New Password',
                ),
              ),
              SizedBox(height: 30),
              Row(
                children: [
                  Text(
                    "Confirm Password",

                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
              SizedBox(height: 10),
              TextField(
                controller: newConfirmPasswordController,
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),

                  hintText: ' Your Confirm Password',
                ),
              ),
              SizedBox(height: 30),

              GestureDetector(
                onTap: () {
                  final newPassword = newPasswordController.text.trim();
                  final newConfirmPassword = newConfirmPasswordController.text
                      .trim();

                  if (newPassword.isEmpty ||
                      newPassword != newConfirmPassword) {
                    debugPrint("Şifreler uyuşmamakta");
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Şifreler uyuşmamakta")),
                    );
                  } else {
                    Navigator.pushNamed(context, '/');
                  }
                },
                child: Container(
                  height: 60,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 23, 35, 44),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text("Save", style: TextStyle(color: Colors.white)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
