// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:loginn/passwordcriteria.dart';
import 'user_storage.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController nameController = TextEditingController();

  final TextEditingController surnameController = TextEditingController();

  final TextEditingController nationalIdController = TextEditingController();

  final TextEditingController emailController = TextEditingController();

  final TextEditingController phoneController = TextEditingController();

  late TextEditingController passwordController;

  final TextEditingController confirmPasswordController =
      TextEditingController();

  late AnimationController controller;
  final _controllers = List.generate(6, (_) => TextEditingController());
  final packages = ['Summer Package', 'Winter Package'];
  String? selectedPackage;
  bool _isValid = false;
  bool showPasswordCard = false;
  String password = '';

  late FocusNode _passwordFocusNode;
  @override
  void initState() {
    super.initState();
    passwordController = TextEditingController();
    _passwordFocusNode = FocusNode();
    // Şifre değişimini dinleme
    passwordController.addListener(() {
      setState(() {
        password = passwordController.text;
      });
    });
    _passwordFocusNode.addListener(() {
      setState(() {
        showPasswordCard = _passwordFocusNode.hasFocus;
      });
    });
    controller =
        AnimationController(vsync: this, duration: const Duration(seconds: 5))
          ..addListener(() {
            setState(() {});
          })
          ..repeat(reverse: true);
    // Listener: her değişiklikte karakter sayısını kontrol eder
    _controllers[4].addListener(() {
      final textLength = _controllers[4].text.length;
      final isNowValid = textLength >= 8;

      // Değer değiştiyse setState çağır
      if (isNowValid != _isValid) {
        setState(() {
          _isValid = isNowValid;
        });
      }
    });
  }

  @override
  void dispose() {
    controller.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }

  Widget uyari(String uyari) {
    return Text(uyari);
  }

  void saveAndGoToTariff(BuildContext context) async {
    var snackbar = ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text("Lütfen tüm alanları doldurunuz")));

    final normalizedPhone = UserStorage.normalizePhone(
      phoneController.text.trim(),
    );
    String name = nameController.text.trim();
    String surName = surnameController.text.trim();
    String nationalId = nationalIdController.text.trim();
    String email = emailController.text.trim();
    String phone = normalizedPhone;
    String passwordC = passwordController.text.trim();
    final userData = {
      'name': name,
      'surname': surName,
      'nationalId': nationalId,
      'email': email,
      'phone': phone,
      'password': password,
    };

    await UserStorage.saveUser(userData);
    if (name.isEmpty ||
        surName.isEmpty ||
        nationalId.isEmpty ||
        nationalId.contains(RegExp(r'[A-Z]')) ||
        email.isEmpty ||
        !email.contains("@") ||
        phone.isEmpty ||
        passwordC.isEmpty ||
        (passwordC != confirmPasswordController.text.trim())) {
      snackbar;
    } else {
      Navigator.pushNamed(context, '/tariff');
    }
  }

  @override
  bool get hasMinLength => password.length >= 8;
  bool get hasUppercase => password.contains(RegExp(r'[A-Z]'));
  bool get hasNumber => password.contains(RegExp(r'[0-9]'));
  bool get hasSymbol => password.contains(RegExp(r'[!@#\$%^&*(),.?":{}|<>]'));
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(children: [Image.asset("images/image 10.png")]),

            Row(
              children: [
                Text(
                  "Sign Up",
                  style: TextStyle(fontSize: 33, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Text(
                  "Name",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
              ],
            ),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: "Your Name",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            Row(
              children: [
                Text(
                  "Surname",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
              ],
            ),
            TextField(
              controller: surnameController,
              decoration: InputDecoration(
                labelText: 'Your Surname',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            Row(
              children: [
                Text(
                  "National ID",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
              ],
            ),
            TextField(
              controller: nationalIdController,
              decoration: InputDecoration(
                labelText: 'Your National ID',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            Row(
              children: [
                Text(
                  "Email",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
              ],
            ),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Your Email',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            Row(
              children: [
                Text(
                  "Phone",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
              ],
            ),
            TextField(
              controller: phoneController,
              decoration: InputDecoration(
                labelText: 'Your Phone',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            Row(
              children: [
                Text(
                  "Password",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
              ],
            ),
            TextField(
              controller: passwordController,
              focusNode: _passwordFocusNode,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Your Password',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            Card(
              elevation: 4,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      PasswordCriteriaRow(
                        text: "At least 8 characters",
                        isValid: hasMinLength,
                      ),
                      PasswordCriteriaRow(
                        text: "At least one uppercase",
                        isValid: hasUppercase,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      PasswordCriteriaRow(
                        text: "At least one number",
                        isValid: hasNumber,
                      ),
                      PasswordCriteriaRow(
                        text: "At least one symbol",
                        isValid: hasSymbol,
                      ),
                    ],
                  ),
                ],
              ),
            ),

            Row(
              children: [
                Text(
                  "Confirm Password",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
              ],
            ),
            TextField(
              controller: confirmPasswordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Your Confirm Password',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 20),
            GestureDetector(
              onTap: () => saveAndGoToTariff(context),
              child: Container(
                height: 60,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 4, 18, 29),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    "Continue",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                height: 60,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 33, 39, 44),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    "Back to login",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
           
          ],
        ),
      ),
    );
  }
}
