// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:loginn/passwordcriteria.dart';
import 'package:loginn/user_storage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController phoneController = TextEditingController();

  late final TextEditingController passwordController;

  void login(BuildContext context) async {
    final inputPhone = UserStorage.normalizePhone(phoneController.text.trim());
    final inputPassword = passwordController.text.trim();

    final savedUser = await UserStorage.getUser();

    if (savedUser != null &&
        savedUser['phone'] == inputPhone &&
        savedUser['password'] == inputPassword) {
      // Başarılı giriş
      Navigator.pushReplacementNamed(context, '/personal');
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Invalid phone or password')));
    }

    /* final phone = phoneController.text.trim();
    final password = passwordController.text.trim();

    final valid = await UserStorage.validateLogin(phone, password);

    if (valid) {
      Navigator.pushReplacementNamed(context, '/personal');
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Invalid phone or password!')));
    }*/
  }

  late FocusNode _passwordFocusNode;

  bool _isValid = false;
  String password = '';

  bool showPasswordCard = false;
  @override
  void initState() {
    super.initState();
    passwordController = TextEditingController();
    _passwordFocusNode = FocusNode();

    // Listener'lar initState içinde tanımlanmalı!
    passwordController.addListener(() {
      setState(() {
        password = passwordController.text;
      });
    });

    _passwordFocusNode.addListener(() {
      setState(() {
        showPasswordCard = _passwordFocusNode.hasFocus;
      });
    });
  }

  @override
  void dispose() {
    passwordController.dispose();
    _passwordFocusNode.dispose(); // 🔴 Eksikti
    super.dispose();
  }

  bool get hasMinLength => password.length >= 8;
  bool get hasUppercase => password.contains(RegExp(r'[A-Z]'));
  bool get hasNumber => password.contains(RegExp(r'[0-9]'));
  bool get hasSymbol => password.contains(RegExp(r'[!@#\$%^&*(),.?":{}|<>]'));
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        toolbarHeight: 80,
        title: Padding(
          padding: const EdgeInsets.only(top: 38.0),
          child: Image.asset("images/image 10.png"),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Text(
                    "WELCOME TO ",
                    style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    "KOTAM",
                    style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    "Track every GB you use,every minute you\nspend with Kotam.",
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    "Phone Number",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
              SizedBox(height: 10),
              TextField(
                controller: phoneController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),

                  hintText: 'Your Phone Number',
                ),
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Text(
                    "Password",

                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
              SizedBox(height: 10),
              TextField(
                controller: passwordController,
                focusNode: _passwordFocusNode,
                obscureText: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),

                  hintText: ' Your Password',
                ),
              ),
              if (showPasswordCard)
                Card(
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            PasswordCriteriaRow(
                              text: "At least 8 \ncharacters",
                              isValid: hasMinLength,
                            ),
                            PasswordCriteriaRow(
                              text: "At least one \nuppercase",
                              isValid: hasUppercase,
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            PasswordCriteriaRow(
                              text: "At least one \nnumber",
                              isValid: hasNumber,
                            ),
                            PasswordCriteriaRow(
                              text: "At least one \nsymbol",
                              isValid: hasSymbol,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, "/Forgot");
                    },
                    child: Text(
                      "Forgot Password",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
              GestureDetector(
                onTap: () => login(context),
                child: Container(
                  height: 60,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 4, 18, 29),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text("Login", style: TextStyle(color: Colors.white)),
                  ),
                ),
              ),
              SizedBox(height: 10),
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/register'),
                child: Container(
                  height: 60,
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 33, 39, 44),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      "Sign Up",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
